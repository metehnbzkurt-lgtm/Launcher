# Hyper Modern Launcher

Modern Android launcher starter inspired by a Soft Glass / HyperOS-like visual language. This is an independent project, not Xiaomi software and not an implementation of every proprietary HyperOS feature.

## Included in this starter
- Android HOME launcher entry point (select it as the default Home app in Android settings)
- Home screen with app shortcuts from installed launchable apps
- App drawer with search and alphabetical sorting
- Modern dark/light UI, rounded panels and accent colors
- Customizable 4- or 5-column layout
- Icon size and icon-label visibility controls
- Compact layout toggle and a few starter preferences

## Build in Android Studio
1. Open this folder as an existing Gradle project.
2. Use JDK 17.
3. Let Android Studio sync Gradle dependencies.
4. Run the `app` configuration on an Android device or emulator (Android 8.0 / API 26+).
5. Press Home and choose **Hyper Modern Launcher** as the default launcher.

## Build on GitHub
Push this project to a GitHub repository. The workflow at `.github/workflows/android.yml` builds a debug APK and uploads it as a workflow artifact.

## Important limitations
This is a functional starter, not a finished replacement for every feature in the supplied specification. Android restricts what third-party launchers can control. Features such as system Recents layout, system-wide blur, HyperIsland, system widgets/stacking, lock-screen behavior, and OEM-only APIs cannot be reproduced just by changing the launcher UI. Preferences currently live in Compose state and reset when the process is recreated; persistent preferences, drag-and-drop placement, folders, widgets, gestures, backup/restore, wallpaper controls and a full grid-based home layout are planned next steps.
