package com.example.hypermodernlauncher

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Ink = Color(0xFF10131C)
private val Panel = Color(0xFF1B2030)
private val Accent = Color(0xFF9B8CFF)
private val Mint = Color(0xFF8BE6D2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LauncherApp() }
    }
}

data class LaunchApp(val label: String, val packageName: String, val icon: Drawable)

@Composable
fun LauncherApp() {
    val context = LocalContext.current
    val pm = context.packageManager
    var screen by remember { mutableStateOf("home") }
    var search by remember { mutableStateOf("") }
    var columns by remember { mutableIntStateOf(4) }
    var iconScale by remember { mutableFloatStateOf(1f) }
    var showLabels by remember { mutableStateOf(true) }
    var compact by remember { mutableStateOf(false) }
    var dark by remember { mutableStateOf(true) }
    var fillGaps by remember { mutableStateOf(true) }
    var newApps by remember { mutableStateOf(true) }
    var drawerSuggestions by remember { mutableStateOf(true) }

    val apps by produceState(initialValue = emptyList<LaunchApp>()) {
        value = withContext(Dispatchers.IO) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
                .mapNotNull { info ->
                    val activity = info.activityInfo
                    if (activity.packageName == context.packageName) null
                    else LaunchApp(
                        info.loadLabel(pm).toString(),
                        activity.packageName,
                        info.loadIcon(pm)
                    )
                }
                .distinctBy { it.packageName }
                .sortedBy { it.label.lowercase() }
        }
    }

    val bg = if (dark) Ink else Color(0xFFF3F5FB)
    val surface = if (dark) Panel else Color.White
    val foreground = if (dark) Color(0xFFF3F4FA) else Color(0xFF171927)
    val muted = if (dark) Color(0xFF9DA5BC) else Color(0xFF686D7E)

    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(
            background = bg, surface = surface, primary = Accent,
            onBackground = foreground, onSurface = foreground
        ) else lightColorScheme(
            background = bg, surface = surface, primary = Color(0xFF6554D9),
            onBackground = foreground, onSurface = foreground
        )
    ) {
        Scaffold(
            containerColor = bg,
            bottomBar = {
                NavigationBar(containerColor = surface, tonalElevation = 0.dp) {
                    NavigationBarItem(
                        selected = screen == "home",
                        onClick = { screen = "home" },
                        icon = { Icon(Icons.Rounded.Home, null) },
                        label = { Text("Ana ekran") }
                    )
                    NavigationBarItem(
                        selected = screen == "apps",
                        onClick = { screen = "apps" },
                        icon = { Icon(Icons.Rounded.Apps, null) },
                        label = { Text("Uygulamalar") }
                    )
                    NavigationBarItem(
                        selected = screen == "customize",
                        onClick = { screen = "customize" },
                        icon = { Icon(Icons.Rounded.Settings, null) },
                        label = { Text("Özelleştir") }
                    )
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)
            ) {
                Spacer(Modifier.height(18.dp))
                when (screen) {
                    "home" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("HYPER", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                                Text("Alanına hoş geldin", color = foreground, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                            }
                            Surface(shape = CircleShape, color = surface, modifier = Modifier.size(48.dp)) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Rounded.Widgets, null, tint = Accent)
                                }
                            }
                        }
                        Spacer(Modifier.height(22.dp))
                        Surface(
                            color = Color(0xFF292746),
                            shape = RoundedCornerShape(28.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(22.dp)) {
                                Text("Gününe odaklan", color = Color.White.copy(alpha = .72f), fontSize = 13.sp)
                                Spacer(Modifier.height(5.dp))
                                Text("Daha sade. Daha hızlı.", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(14.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Tag("Minimal", Color(0xFF9B8CFF))
                                    Tag("Akıcı", Mint)
                                    Tag("Kişisel", Color(0xFFFFC98B))
                                }
                            }
                        }
                        Spacer(Modifier.height(24.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Favori uygulamalar", color = foreground, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            Text("Tümünü gör  ›", color = Accent, modifier = Modifier.clickable { screen = "apps" })
                        }
                        Spacer(Modifier.height(12.dp))
                        val favorites = apps.take(8)
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(columns),
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(bottom = 18.dp)
                        ) {
                            items(favorites, key = { it.packageName }) { app ->
                                AppTile(app, showLabels, iconScale, foreground) {
                                    launchApp(context, app.packageName)
                                }
                            }
                        }
                        Text("İpucu: Uygulamalar sekmesinden arama yapabilir, Özelleştir'den düzeni değiştirebilirsin.", color = muted, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(bottom = 12.dp))
                    }
                    "apps" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Uygulamalar", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = foreground, modifier = Modifier.weight(1f))
                            Text("${apps.size}", color = muted)
                        }
                        Spacer(Modifier.height(14.dp))
                        OutlinedTextField(
                            value = search, onValueChange = { search = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Uygulama ara…") },
                            leadingIcon = { Icon(Icons.Rounded.Search, null) },
                            singleLine = true,
                            shape = RoundedCornerShape(18.dp)
                        )
                        Spacer(Modifier.height(12.dp))
                        val filtered = apps.filter { it.label.contains(search, true) }
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(columns),
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(bottom = 20.dp, top = 4.dp)
                        ) {
                            items(filtered, key = { it.packageName }) { app ->
                                AppTile(app, showLabels, iconScale, foreground) {
                                    launchApp(context, app.packageName)
                                }
                            }
                        }
                    }
                    else -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Özelleştir", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = foreground)
                        }
                        Text("Görünümünü kendine göre ayarla", color = muted, modifier = Modifier.padding(top = 5.dp, bottom = 18.dp))
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(bottom = 22.dp)
                        ) {
                            item {
                                SettingCard("Ana ekran ızgarası", "Sütun sayısı: $columns") {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf(4, 5).forEach { count ->
                                            FilterChip(selected = columns == count, onClick = { columns = count }, label = { Text("${count}×") })
                                        }
                                    }
                                }
                            }
                            item {
                                SettingCard("İkon boyutu", when {
                                    iconScale < .9f -> "Küçük"
                                    iconScale > 1.1f -> "Büyük"
                                    else -> "Orta"
                                }) {
                                    Slider(value = iconScale, onValueChange = { iconScale = it }, valueRange = .75f..1.25f)
                                }
                            }
                            item {
                                SettingCard("Koyu tema", "Gece görünümü") {
                                    Switch(checked = dark, onCheckedChange = { dark = it })
                                }
                            }
                            item {
                                SettingCard("İkon isimleri", "Uygulama etiketleri") {
                                    Switch(checked = showLabels, onCheckedChange = { showLabels = it })
                                }
                            }
                            item {
                                SettingCard("Yoğun düzen", "Daha sıkı yerleşim") {
                                    Switch(checked = compact, onCheckedChange = {
                                        compact = it
                                        columns = if (it) 5 else 4
                                    })
                                }
                            }
                            item {
                                SettingCard("Boşlukları doldur", "Düzeni sıkı tut") {
                                    Switch(checked = fillGaps, onCheckedChange = { fillGaps = it })
                                }
                            }
                            item {
                                SettingCard("Yeni uygulamalar", "Ana ekrana ekleme tercihi") {
                                    Switch(checked = newApps, onCheckedChange = { newApps = it })
                                }
                            }
                            item {
                                SettingCard("Öneriler", "Uygulama çekmecesi") {
                                    Switch(checked = drawerSuggestions, onCheckedChange = { drawerSuggestions = it })
                                }
                            }
                            item {
                                SettingCard("Görünüm profili", "Soft Glass") {
                                    Text("Etkin", color = Accent, fontWeight = FontWeight.Bold)
                                }
                            }
                            item {
                                SettingCard("Launcher bilgisi", "Sürüm 0.1.0") {
                                    Text("Android 8+", color = muted, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Tag(label: String, color: Color) {
    Surface(color = color.copy(alpha = .17f), shape = RoundedCornerShape(50)) {
        Text(label, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp))
    }
}

@Composable
private fun AppTile(app: LaunchApp, showLabels: Boolean, scale: Float, foreground: Color, onClick: () -> Unit) {
    val bitmap = remember(app.packageName) { app.icon.toBitmap(144, 144).asImageBitmap() }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(vertical = 5.dp)
    ) {
        androidx.compose.foundation.Image(
            bitmap = bitmap, contentDescription = app.label,
            modifier = Modifier.size((48 * scale).dp)
        )
        if (showLabels) {
            Spacer(Modifier.height(7.dp))
            Text(app.label, color = foreground, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

@Composable
private fun SettingCard(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

private fun launchApp(context: android.content.Context, packageName: String) {
    val intent = context.packageManager.getLaunchIntentForPackage(packageName)
    if (intent != null) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}
