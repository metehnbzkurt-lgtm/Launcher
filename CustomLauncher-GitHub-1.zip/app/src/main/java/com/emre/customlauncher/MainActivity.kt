package com.emre.customlauncher

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.emre.customlauncher.settings.SettingsActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    private var drawerOpen by mutableStateOf(false)
    private var tick by mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LPrefs.init(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
        }
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = false
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                LauncherRoot(tick, drawerOpen) { drawerOpen = it }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Ana ekran tusuna basilinca uygulama menusunu kapat
        drawerOpen = false
    }
}

@Composable
fun LauncherRoot(tick: Int, drawerOpen: Boolean, setDrawer: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }

    LaunchedEffect(tick) {
        val loaded = withContext(Dispatchers.IO) { AppRepo.load(ctx) }
        apps = loaded
        LPrefs.ensureDockDefaults(loaded)
    }

    val byKey = remember(apps) { apps.associateBy { it.key } }
    BackHandler(enabled = drawerOpen) { setDrawer(false) }

    Box(Modifier.fillMaxSize()) {
        HomeScreen(byKey) { setDrawer(true) }
        AnimatedVisibility(
            visible = drawerOpen,
            enter = slideInVertically { it / 2 } + fadeIn(),
            exit = slideOutVertically { it / 2 } + fadeOut()
        ) {
            DrawerScreen(apps) { setDrawer(false) }
        }
    }
}

@Composable
fun HomeScreen(byKey: Map<String, AppInfo>, onOpenDrawer: () -> Unit) {
    val ctx = LocalContext.current
    var bgMenu by remember { mutableStateOf(false) }
    val cols = LPrefs.homeCols.value
    val rows = LPrefs.homeRows.value
    val entries = LPrefs.homeEntries()
    val dock = LPrefs.dockKeys().mapNotNull { byKey[it] }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -120f) onOpenDrawer() },
                    onDragCancel = { },
                    onVerticalDrag = { _, dy -> total += dy }
                )
            }
    ) {
        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .pointerInput(Unit) {
                    detectTapGestures(onLongPress = { bgMenu = true })
                }
        ) {
            val cw = maxWidth / cols
            val ch = maxHeight / rows
            entries.forEach { (key, idx) ->
                val app = byKey[key] ?: return@forEach
                if (idx >= cols * rows) return@forEach
                Box(
                    Modifier
                        .offset(cw * (idx % cols), ch * (idx / cols))
                        .size(cw, ch),
                    contentAlignment = Alignment.Center
                ) {
                    AppCell(
                        app, LPrefs.homeIconSize.value, LPrefs.homeLabels.value, cw,
                        listOf<Pair<String, () -> Unit>>(
                            "Kaldır" to { LPrefs.removeHome(key) },
                            "Uygulama bilgisi" to { AppActions.info(ctx, app) }
                        )
                    ) { AppActions.launch(ctx, app) }
                }
            }
            DropdownMenu(expanded = bgMenu, onDismissRequest = { bgMenu = false }) {
                DropdownMenuItem(text = { Text("Ayarlar") }, onClick = {
                    bgMenu = false
                    ctx.startActivity(Intent(ctx, SettingsActivity::class.java))
                })
                DropdownMenuItem(text = { Text("Duvar kağıdı") }, onClick = {
                    bgMenu = false
                    try {
                        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Duvar kağıdı"))
                    } catch (e: Exception) {
                        AppActions.toast(ctx, "Açılamadı")
                    }
                })
                DropdownMenuItem(text = { Text("Varsayılan launcher yap") }, onClick = {
                    bgMenu = false
                    try {
                        ctx.startActivity(Intent(AndroidSettings.ACTION_HOME_SETTINGS))
                    } catch (e: Exception) {
                        AppActions.toast(ctx, "Açılamadı")
                    }
                })
            }
        }

        // Uygulama menusunu acan ok
        Box(Modifier.fillMaxWidth().clickable { onOpenDrawer() }.padding(vertical = 4.dp), contentAlignment = Alignment.Center) {
            Text("▲", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
        }

        // Dock
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .background(Color(0x55000000), RoundedCornerShape(28.dp))
                .heightIn(min = 76.dp)
                .padding(horizontal = 6.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            dock.forEach { app ->
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    AppCell(
                        app, LPrefs.homeIconSize.value, false, 80.dp,
                        listOf<Pair<String, () -> Unit>>(
                            "Dock'tan kaldır" to { LPrefs.removeDock(app.key) },
                            "Uygulama bilgisi" to { AppActions.info(ctx, app) }
                        )
                    ) { AppActions.launch(ctx, app) }
                }
            }
        }
    }
}

@Composable
fun DrawerScreen(apps: List<AppInfo>, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    val cols = LPrefs.drawerCols.value
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }
    val pos = LPrefs.searchPos.value
    val cellW = LocalConfiguration.current.screenWidthDp.dp / cols

    val go: () -> Unit = {
        filtered.firstOrNull()?.let {
            AppActions.launch(ctx, it)
            onClose()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = LPrefs.drawerBgAlpha.value / 100f))
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        if (pos == "Üst") DrawerSearchBar(query, { query = it }, go)
        LazyVerticalGrid(
            columns = GridCells.Fixed(cols),
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
        ) {
            items(filtered, key = { it.key }) { app ->
                Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                    AppCell(
                        app, LPrefs.drawerIconSize.value, LPrefs.drawerLabels.value, cellW,
                        listOf<Pair<String, () -> Unit>>(
                            "Ana ekrana ekle" to { AppActions.toast(ctx, LPrefs.addHome(app.key)) },
                            "Dock'a ekle" to { AppActions.toast(ctx, LPrefs.addDock(app.key)) },
                            "Uygulama bilgisi" to { AppActions.info(ctx, app) },
                            "Kaldır" to { AppActions.uninstall(ctx, app) }
                        )
                    ) {
                        AppActions.launch(ctx, app)
                        onClose()
                    }
                }
            }
        }
        if (pos == "Alt") DrawerSearchBar(query, { query = it }, go)
    }
}

private fun logoGlyph(type: String): String = when (type) {
    "keyboard_search" -> "⌨"
    "google" -> "G"
    "monochrome" -> "◎"
    else -> "🔍"
}

@Composable
fun DrawerSearchBar(query: String, onQuery: (String) -> Unit, onGo: () -> Unit) {
    val shape = RoundedCornerShape(LPrefs.searchCorner.value.dp)
    val alpha = 1f - LPrefs.searchTransparency.value / 100f
    var m = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
    if (LPrefs.searchDesign.value) {
        if (LPrefs.searchShadow.value) m = m.shadow(8.dp, shape)
        m = m.background(Color(0xFF1E1E1E).copy(alpha = alpha), shape)
    }
    Row(
        m.padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(logoGlyph(LPrefs.searchLogo.value), color = Color.White, fontSize = 18.sp)
        Spacer(Modifier.width(12.dp))
        Box(Modifier.weight(1f)) {
            if (query.isEmpty()) Text("Uygulama ara", color = Color.Gray, fontSize = 16.sp)
            BasicTextField(
                value = query,
                onValueChange = onQuery,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Color.White),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onGo() }),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCell(
    app: AppInfo,
    iconScale: Int,
    showLabel: Boolean,
    maxW: Dp,
    menu: List<Pair<String, () -> Unit>>,
    onClick: () -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Box {
        Column(
            Modifier
                .widthIn(max = maxW)
                .combinedClickable(onClick = onClick, onLongClick = { open = true })
                .padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                bitmap = app.icon,
                contentDescription = app.label,
                modifier = Modifier.size((44 * iconScale / 100f).dp)
            )
            if (showLabel) {
                Text(
                    app.label,
                    style = TextStyle(color = Color.White, fontSize = 11.sp, shadow = Shadow(Color.Black, blurRadius = 6f)),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            menu.forEach { (title, action) ->
                DropdownMenuItem(text = { Text(title) }, onClick = {
                    open = false
                    action()
                })
            }
        }
    }
}
