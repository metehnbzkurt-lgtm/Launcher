package com.emre.customlauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings as AndroidSettings
import android.widget.Toast
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import java.text.Collator
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

data class AppInfo(
    val key: String,
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val icon: ImageBitmap
)

object AppRepo {
    private val iconCache = ConcurrentHashMap<String, ImageBitmap>()

    fun load(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(intent, 0).mapNotNull { ri ->
            val ai = ri.activityInfo ?: return@mapNotNull null
            if (ai.packageName == ctx.packageName) return@mapNotNull null
            val cn = ComponentName(ai.packageName, ai.name)
            val key = cn.flattenToString()
            val icon = iconCache.getOrPut(key) { ri.loadIcon(pm).toBitmap(144, 144).asImageBitmap() }
            AppInfo(key, ri.loadLabel(pm).toString(), ai.packageName, cn, icon)
        }
        val collator = Collator.getInstance(Locale("tr"))
        return list.sortedWith(Comparator<AppInfo> { a, b -> collator.compare(a.label, b.label) })
    }
}

object AppActions {
    fun launch(ctx: Context, app: AppInfo) {
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(app.component)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        } catch (e: Exception) {
            toast(ctx, "Uygulama açılamadı")
        }
    }

    fun info(ctx: Context, app: AppInfo) {
        try {
            ctx.startActivity(
                Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            toast(ctx, "Açılamadı")
        }
    }

    fun uninstall(ctx: Context, app: AppInfo) {
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.pkg))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            toast(ctx, "Kaldırılamadı")
        }
    }

    fun toast(ctx: Context, msg: String) {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }
}
