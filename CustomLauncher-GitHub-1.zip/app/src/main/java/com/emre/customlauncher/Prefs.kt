package com.emre.customlauncher

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf

/** Kalici ayarlar. Her ayar Compose state'i: degisince ekran kendiliginden yenilenir. */
object LPrefs {
    private val all = mutableListOf<Setting<*>>()
    lateinit var sp: SharedPreferences

    fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.applicationContext.getSharedPreferences("launcher_prefs", Context.MODE_PRIVATE)
        all.forEach { it.load() }
    }

    abstract class Setting<T>(val key: String, val def: T) {
        private val state = mutableStateOf(def)
        val value: T get() = state.value
        init { LPrefs.all.add(this) }
        abstract fun read(sp: SharedPreferences): T
        abstract fun write(e: SharedPreferences.Editor, v: T)
        fun load() { state.value = read(LPrefs.sp) }
        fun set(v: T) {
            state.value = v
            val e = LPrefs.sp.edit()
            write(e, v)
            e.apply()
        }
    }

    class IntS(key: String, def: Int) : Setting<Int>(key, def) {
        override fun read(sp: SharedPreferences): Int = sp.getInt(key, def)
        override fun write(e: SharedPreferences.Editor, v: Int) { e.putInt(key, v) }
    }

    class BoolS(key: String, def: Boolean) : Setting<Boolean>(key, def) {
        override fun read(sp: SharedPreferences): Boolean = sp.getBoolean(key, def)
        override fun write(e: SharedPreferences.Editor, v: Boolean) { e.putBoolean(key, v) }
    }

    class StrS(key: String, def: String) : Setting<String>(key, def) {
        override fun read(sp: SharedPreferences): String = sp.getString(key, def) ?: def
        override fun write(e: SharedPreferences.Editor, v: String) { e.putString(key, v) }
    }

    // Ana ekran
    val homeIconSize = IntS("home_icon_size", 125)
    val homeLabels = BoolS("home_labels", true)
    val homeCols = IntS("home_cols", 5)
    val homeRows = IntS("home_rows", 7)

    // Uygulama menusu
    val drawerIconSize = IntS("drawer_icon_size", 125)
    val drawerLabels = BoolS("drawer_labels", true)
    val drawerCols = IntS("drawer_cols", 5)
    val drawerBgAlpha = IntS("drawer_bg_alpha", 85)

    // Arama cubugu
    val searchPos = StrS("search_pos", "Alt") // Alt, Üst, Hiçbiri
    val searchTransparency = IntS("search_transparency", 0)
    val searchCorner = IntS("search_corner", 22)
    val searchDesign = BoolS("search_design", true)
    val searchShadow = BoolS("search_shadow", true)
    val searchLogo = StrS("search_logo", "dots_search")

    // Ana ekran ogeleri ("anahtar|hucre" satirlari) ve dock ("anahtar" satirlari)
    val homeItems = StrS("home_items", "")
    val dockItems = StrS("dock_items", "")
    val dockInit = BoolS("dock_init", false)

    fun homeEntries(): List<Pair<String, Int>> =
        homeItems.value.lines().mapNotNull { l ->
            val p = l.split("|")
            if (p.size == 2) p[1].toIntOrNull()?.let { p[0] to it } else null
        }

    private fun setHome(list: List<Pair<String, Int>>) {
        homeItems.set(list.joinToString("\n") { it.first + "|" + it.second })
    }

    fun dockKeys(): List<String> = dockItems.value.lines().filter { it.isNotBlank() }

    fun addHome(key: String): String {
        val e = homeEntries()
        if (e.any { it.first == key }) return "Zaten ana ekranda"
        val cap = homeCols.value * homeRows.value
        val used = e.map { it.second }.toSet()
        val free = (0 until cap).firstOrNull { it !in used } ?: return "Ana ekran dolu"
        setHome(e + Pair(key, free))
        return "Ana ekrana eklendi"
    }

    fun removeHome(key: String) {
        setHome(homeEntries().filter { it.first != key })
    }

    fun addDock(key: String): String {
        val d = dockKeys()
        if (key in d) return "Zaten dock'ta"
        if (d.size >= 5) return "Dock dolu (en fazla 5)"
        dockItems.set((d + key).joinToString("\n"))
        dockInit.set(true)
        return "Dock'a eklendi"
    }

    fun removeDock(key: String) {
        dockItems.set(dockKeys().filter { it != key }.joinToString("\n"))
        dockInit.set(true)
    }

    /** Ilk acilista dock'a telefon, mesaj, tarayici ve kamera uygulamalarini koyar. */
    fun ensureDockDefaults(apps: List<AppInfo>) {
        if (apps.isEmpty() || dockInit.value) return
        val groups = listOf(
            listOf("dialer"),
            listOf("messag", "mms", "sms"),
            listOf("chrome", "browser", "brave", "firefox"),
            listOf("camera")
        )
        val picked = groups.mapNotNull { g ->
            apps.firstOrNull { a -> g.any { a.pkg.contains(it, ignoreCase = true) } }?.key
        }.distinct()
        dockItems.set(picked.joinToString("\n"))
        dockInit.set(true)
    }
}
