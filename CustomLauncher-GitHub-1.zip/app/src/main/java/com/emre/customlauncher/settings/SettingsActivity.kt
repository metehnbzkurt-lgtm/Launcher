package com.emre.customlauncher.settings

import android.content.Intent
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.emre.customlauncher.LPrefs

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LPrefs.init(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                SettingsScreen()
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    Scaffold { padding ->
        LazyColumn(Modifier.padding(padding).padding(horizontal = 16.dp)) {
            item {
                Text("Launcher Ayarları", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 16.dp))
                Button(
                    onClick = {
                        try { ctx.startActivity(Intent(AndroidSettings.ACTION_HOME_SETTINGS)) } catch (e: Exception) { }
                    },
                    modifier = Modifier.padding(top = 12.dp)
                ) { Text("Varsayılan launcher yap") }
            }

            item { SectionTitle("Ana ekran") }
            item { SliderRow("Simge boyutu", LPrefs.homeIconSize, 50..150, "%") }
            item { SwitchRow("Etiketleri göster", LPrefs.homeLabels) }
            item { StepperRow("Sütun", LPrefs.homeCols, 3, 8) }
            item { StepperRow("Satır", LPrefs.homeRows, 3, 10) }
            item {
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { LPrefs.homeItems.set("") }) { Text("Ana ekranı temizle") }
                    OutlinedButton(onClick = { LPrefs.dockItems.set(""); LPrefs.dockInit.set(false) }) { Text("Dock'u sıfırla") }
                }
            }

            item { SectionTitle("Uygulama menüsü") }
            item { SliderRow("Simge boyutu", LPrefs.drawerIconSize, 50..150, "%") }
            item { SwitchRow("Etiketleri göster", LPrefs.drawerLabels) }
            item { StepperRow("Sütun", LPrefs.drawerCols, 3, 7) }
            item { SliderRow("Arka plan koyuluğu", LPrefs.drawerBgAlpha, 0..100, "%") }

            item { SectionTitle("Arama çubuğu") }
            item {
                ChipsRow(
                    "Yerleştirme",
                    listOf("Alt" to "Alt", "Üst" to "Üst", "Hiçbiri" to "Hiçbiri"),
                    LPrefs.searchPos
                )
            }
            item { SliderRow("Şeffaflık", LPrefs.searchTransparency, 0..100, "%") }
            item { SliderRow("Köşe yarıçapı", LPrefs.searchCorner, 0..46, "dp") }
            item { SwitchRow("Tasarım (arka plan)", LPrefs.searchDesign) }
            item { SwitchRow("Gölge", LPrefs.searchShadow) }
            item {
                ChipsRow(
                    "Logo",
                    listOf(
                        "dots_search" to "●🔍",
                        "keyboard_search" to "⌨",
                        "search" to "🔍",
                        "google" to "G",
                        "monochrome" to "◎"
                    ),
                    LPrefs.searchLogo
                )
            }
            item { Spacer(Modifier.height(32.dp)) }
        }
    }
}

@Composable
fun SectionTitle(t: String) {
    Text(
        t,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
    )
}

@Composable
fun SliderRow(title: String, s: LPrefs.IntS, range: IntRange, suffix: String = "") {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(title + ": " + s.value + suffix)
        Slider(
            value = s.value.toFloat(),
            onValueChange = { s.set(it.toInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat()
        )
    }
}

@Composable
fun SwitchRow(title: String, s: LPrefs.BoolS) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        Switch(checked = s.value, onCheckedChange = { s.set(it) })
    }
}

@Composable
fun StepperRow(title: String, s: LPrefs.IntS, min: Int, max: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        OutlinedButton(onClick = { if (s.value > min) s.set(s.value - 1) }) { Text("−") }
        Text(s.value.toString(), Modifier.padding(horizontal = 12.dp))
        OutlinedButton(onClick = { if (s.value < max) s.set(s.value + 1) }) { Text("+") }
    }
}

@Composable
fun ChipsRow(title: String, options: List<Pair<String, String>>, s: LPrefs.StrS) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(title)
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            options.forEach { (value, label) ->
                if (s.value == value) {
                    Button(
                        onClick = { s.set(value) },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(0.dp)
                    ) { Text(label, maxLines = 1) }
                } else {
                    OutlinedButton(
                        onClick = { s.set(value) },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(0.dp)
                    ) { Text(label, maxLines = 1) }
                }
            }
        }
    }
}
