# Custom Lawnchair – Nova Edition (çalışan launcher)

Özellikler: ana ekran (ızgara), dock, uygulama menüsü (yukarı kaydır / ▲), arama çubuğu,
uzun basma menüleri, çalışan ayarlar (boyutlar, ızgara, arama çubuğu stili).

## GitHub'da derleme
1. Repo köküne bu zip'i (tek zip olsun) yükle. `.github/workflows/build.yml` yerinde olmalı.
2. Actions > Build APK > Artifacts > `CustomLauncher-debug-apk`.
