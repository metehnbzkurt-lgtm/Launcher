# Nova Launcher - Android Projesi

## GitHub'a Yükleme
1. GitHub'da **New repository** > **Private** seç > oluştur.
2. Bu zip'in içindeki dosyaları, zip kökünden olduğu gibi (iç içe klasör olmadan) depoya yükle ya da `git push` yap:
```bash
git init
git add .
git commit -m "initial"
git branch -M main
git remote add origin https://github.com/KULLANICI/REPO.git
git push -u origin main
```
3. Web arayüzünde sürükle-bırak ile `.github` klasörü yüklenmeyebilir. Bu durumda **Add file > Create new file** de, dosya adı kutusuna `.github/workflows/android.yml` yaz (eğik çizgiler klasörleri oluşturur) ve zip'teki `android.yml` içeriğini yapıştırıp commit et.
4. **Actions** sekmesine gir; push sonrası workflow kendiliğinden çalışır. Elle başlatmak için **Android Build > Run workflow**.

## APK Nereden İndirilir?
**Actions** > son çalıştırma (run) > sayfanın altındaki **Artifacts** > **app-release** indir. Zip'in içinden `app-release.apk` çıkar.

## İmza / Keystore - ÇOK ÖNEMLİ
- `app/nova-release.keystore` bu depoda duruyor. Aynı keystore ile imzalanan her yeni APK, telefondaki eski APK'nın üstüne **veri kaybı olmadan** güncellenir.
- Depoyu mutlaka **Private** tut. Keystore ve şifresi (`app/build.gradle.kts` içinde) depoda olduğu için public yapma.
- Keystore dosyasını silme ve kaybetme: değişirse imza değişir, telefona güncelleme olarak yüklenmez.
- Keystore yoksa proje debug imzasına döner, derleme kırılmaz ama güncelleme imzası değişir.

## Notlar
- `gradlew` gerekmez; GitHub Actions Gradle 8.9'u kendisi kurar.
- Release'de minify + shrinkResources açık, lint derlemeyi kırmaz.
- Güncelleme göstermek için her yeni sürümde `app/build.gradle.kts` içinde `versionCode` değerini artır.
