# Uygulama sinifleri (ViewBinding dahil) korunur
-keep class com.novalauncher.** { *; }
-dontwarn java.lang.invoke.**
