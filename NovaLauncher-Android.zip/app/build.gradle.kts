plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Sabit imza: keystore depoda duruyor. Dosya yoksa debug imzasina donulur.
val novaKeystore = file("nova-release.keystore")

android {
    namespace = "com.novalauncher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.novalauncher"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    signingConfigs {
        if (novaKeystore.exists()) {
            create("release") {
                storeFile = novaKeystore
                storePassword = "nova1234"
                keyAlias = "nova"
                keyPassword = "nova1234"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = if (novaKeystore.exists()) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
        }
        debug {
            isMinifyEnabled = false
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { viewBinding = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
