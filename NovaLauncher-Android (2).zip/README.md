# Nova Launcher - Android Projesi
## GitHub'a Yükleme
1. GitHub'da New repository > **Private** seç > oluştur.
2. Bu zip'in içindeki dosyaları zip kökünden olduğu gibi yükle / `git push` yap:
```bash
git init
git add .
git commit -m "initial"
git branch -M main
git remote add origin https://github.com/KULLANICI/REPO.git
git push -u origin main
```
3. **Actions** sekmesine gir, workflow çalışsın.
## APK Nereden İndirilir?
Actions > son çalıştırma (run) > **Artifacts** > **app-release** > `app-release.apk` indir.
## İmza / Keystore - ÇOK ÖNEMLİ
- `app/nova-release.keystore` bu depoda duruyor. Aynı keystore ile imzalanan her yeni APK, telefondaki eski APK'nın üstüne **veri kaybı olmadan** güncellenir.
- Depoyu mutlaka **Private** tut. Keystore + şifre depoda olduğu için public yapma.
- Keystore yoksa proje debug imzasına döner, derleme kırılmaz ama güncelleme imzası değişir.
## Notlar
- gradlew gerekmez; GitHub Actions Gradle 8.9'u kendisi kurar.
- release'de minify + shrinkResources açık, lint derlemeyi kırmaz.
