plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.novalauncher"
    compileSdk = 34
    defaultConfig { applicationId = "com.novalauncher"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    signingConfigs {
        // Keystore varsa sabit imza, yoksa debug imzasina don (derleme kirilmasin)
        create("release") {
            val ks = file("nova-release.keystore")
            if (ks.exists()) {
                storeFile = ks
                storePassword = "nova1234"
                keyAlias = "nova"
                keyPassword = "nova1234"
            } else {
                // debug fallback: signingConfigs.debug degerleri kullanilir
                storeFile = file("debug.keystore")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Keystore varsa release imzasi, yoksa debug imzasi ile imzala (fallback)
            signingConfig = if (file("nova-release.keystore").exists()) signingConfigs.getByName("release") else signingConfigs.getByName("debug")
        }
        debug { isMinifyEnabled = false; isShrinkResources = false }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { viewBinding = true }
}
dependencies { implementation("androidx.core:core-ktx:1.13.1"); implementation("androidx.appcompat:appcompat:1.7.0"); implementation("com.google.android.material:material:1.12.0") }
