package com.novalauncher
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.novalauncher.databinding.ActivityMainBinding
class MainActivity: AppCompatActivity(){
  private lateinit var binding: ActivityMainBinding
  override fun onCreate(savedInstanceState: Bundle?){
    super.onCreate(savedInstanceState)
    binding = ActivityMainBinding.inflate(layoutInflater)
    setContentView(binding.root)
    binding.searchBar.setOnClickListener{ Toast.makeText(this,"Nova Search",Toast.LENGTH_SHORT).show() }
    binding.drawerButton.setOnClickListener{ Toast.makeText(this,"App Drawer",Toast.LENGTH_SHORT).show() }
    binding.folderSocial.setOnClickListener{ Toast.makeText(this,"Sosyal Klasoru",Toast.LENGTH_SHORT).show() }
    binding.settingsButton.setOnClickListener{ Toast.makeText(this,"Nova Ayarlari",Toast.LENGTH_SHORT).show() }
  }
}
