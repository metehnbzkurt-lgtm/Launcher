rootProject.name = "NovaLauncher"
include(":app")
