# Nova Launcher - Android Projesi

## GitHub'a Zip ile Yukleme
1. Zip'i indir.
2. GitHub'da New repository > Private sec > olustur.
3. Upload files de, zip'in icindeki dosyalari yukle. Sadece zip yuklediysen bile workflow zip'i kendisi acar.
4. .github gorunmezse: Add file -> Create new file, dosya adina .github/workflows/android.yml yaz, kodu yapistir.
5. Actions > son run > Artifacts > app-release

## Keystore - Private Tut!
app/nova-release.keystore depoda. Ayni imzayla APK eski surumun ustune veri kaybi olmadan guncellenir.
