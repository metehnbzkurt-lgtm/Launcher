
package com.emre.customlauncher

import kotlinx.coroutines.flow.MutableStateFlow

// Senin ekran görüntülerindeki tüm ayarlar için tek data model
data class SearchBarPrefs(
    var position: String = "Alt", // Alt, Üst, Hiçbiri
    var transparency: Int = 0,
    var designEnabled: Boolean = true,
    var shadowEnabled: Boolean = true,
    var cornerRadius: Int = 22,
    var logoType: String = "dots_search", // dots_search, keyboard_search, search, google, monochrome
    var extraActions: List<ExtraAction> = listOf(
        ExtraAction("Hava durumu", true, true),
        ExtraAction("Play Store", true, false),
        ExtraAction("Sesli ara", false, false)
    )
)

data class ExtraAction(val name: String, var enabled: Boolean, var hasSettings: Boolean)

data class FolderPrefs(
    var iconSize: Int = 125,
    var matchHomeScreenSize: Boolean = true,
    var showLabel: Boolean = true,
    var colors: String = "Otomatik",
    var style: String = "Pencere", // Pencere, Klasik
    var shadow: Boolean = true,
    var cornerRadius: Int = 46,
    var showFolderName: Boolean = true,
    var scrollDirection: String = "Yatay", // Yatay, Dikey
    var guide: String = "AUTO"
)

data class AppearancePrefs(
    var iconStyle: String = "Sistem",
    var allowRotation: Boolean = false,
    var appAnimation: String = "Sistem",
    var popupMenuStyle: String = "Lawnchair",
    var showDropTargets: Boolean = false,
    var showUndoBar: Boolean = true,
    var disableAnimations: Boolean = false,
    var showStatusBar: Boolean = true,
    var transparentStatusBar: Boolean = true,
    var transparentNavBar: Boolean = true,
    var darkIcons: String = "Otomatik"
)

data class HomeScreenPrefs(
    var iconSize: Int = 125,
    var showLabel: Boolean = true,
    var gridSize: Pair<Int,Int> = 7 to 5,
    var fill: String = "Küçük x Hiçbiri",
    var searchBarPosition: String = "Hiçbiri",
    var wallpaperScrolling: String = "Açık",
    var widgetCornerRadius: Int = 16,
    var transitionEffect: String = "Standart",
    var infiniteScroll: Boolean = false,
    var pageIndicator: String = "Hiçbiri"
)

data class AppDrawerPrefs(
    var iconSize: Int = 125,
    var matchHomeSize: Boolean = true,
    var showLabel: Boolean = true,
    var gridSize: Pair<Int,Int> = 6 to 5,
    var drawerStyle: String = "Dikey",
    var transitionAnim: String = "Yukarı kaydır",
    var searchBarPos: String = "Alt",
    var tabBarPos: String = "Hiçbiri",
    var showFrequentApps: Boolean = false,
    var showFrequentShortcuts: Boolean = false,
    var smartFolders: Boolean = true,
    var openDrawerMode: String = "Kaydır",
    var pullToSearch: Boolean = false,
    var showKeyboard: Boolean = false,
    var fastScrollbar: Boolean = true,
    var showFoldersFirst: Boolean = true
)

object PrefsStore {
    val searchBar = MutableStateFlow(SearchBarPrefs())
    val folder = MutableStateFlow(FolderPrefs())
    val appearance = MutableStateFlow(AppearancePrefs())
    val home = MutableStateFlow(HomeScreenPrefs())
    val drawer = MutableStateFlow(AppDrawerPrefs())
}
