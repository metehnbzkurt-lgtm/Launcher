
package com.emre.customlauncher

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import com.emre.customlauncher.settings.SettingsActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Lawnchair Launcher3 tabanlı - burada Launcher activity olacak
        // Şimdilik ayarlara yönlendir
        startActivity(Intent(this, SettingsActivity::class.java))
    }
}
