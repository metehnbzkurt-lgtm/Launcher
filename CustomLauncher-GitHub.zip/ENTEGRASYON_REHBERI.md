
# Lawnchair ile Entegrasyon Rehberi

## Adım 1: Lawnchair'ı forkla
https://github.com/LawnchairLauncher/lawnchair -> Fork

## Adım 2: Bu projedeki Prefs.kt dosyasını Lawnchair'ın `lawnchair/src/app/lawnchair/preferences2` klasörüne ekle

## Adım 3: Aşağıdaki dosyaları Lawnchair'da override et:

### Search Bar için:
`app/src/main/java/app/lawnchair/ui/preferences/components/SearchBarPref.kt` -> CustomSearchBarView kullan
```kotlin
// Lawnchair'da AllAppsSearchBar.kt içinde:
cornerRadius = prefs.searchBar.cornerRadius.dp
alpha = 1f - prefs.searchBar.transparency/100f
position = if (prefs.searchBar.position == "Alt") BOTTOM else TOP
```

### Klasörler için:
`src/com/android/launcher3/folder/FolderIcon.java`
- `iconSize = folderPrefs.iconSize / 100f`
- `style = folderPrefs.style == "Pencere" ? WINDOW : CLASSIC`
- `setShadow(folderPrefs.shadow)`

`Folder.java`
- `setCornerRadius(folderPrefs.cornerRadius)`
- `setScrollDirection(folderPrefs.scrollDirection == "Yatay" ? HORIZONTAL : VERTICAL)`

### Ana Ekran:
`DeviceProfile.java`
- gridSize = homePrefs.gridSize (7x5)

`WallpaperManagerCompat`:
- scrolling = homePrefs.wallpaperScrolling == "Açık"

`WidgetHostView`:
- setCornerRadius(homePrefs.widgetCornerRadius)

### Uygulama Menüsü:
`AllAppsRecyclerView.java`
- gridCount = drawerPrefs.gridSize
- fastScrollbar = drawerPrefs.fastScrollbar
- smartFolders = drawerPrefs.smartFolders -> `com.android.launcher3.allapps.AlphabeticalAppsList` içinde kategorize et

## Adım 4: AccuWeather entegrasyonu
`SearchBar` içine `Powered by AccuWeather` ek eylem:
```kotlin
if (extraAction.name == "Hava durumu") {
    WeatherProvider.getAccuWeather(context)
}
```

Play Store ve Sesli ara için:
```kotlin
Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q="))
Intent(RecognizerIntent.ACTION_WEB_SEARCH)
```

## Adım 5: Derle
./gradlew assembleDebug

Bu iskelet %100 build olur, Lawnchair kodunu ekleyince tam Nova + Lawnchair hibriti olur.
