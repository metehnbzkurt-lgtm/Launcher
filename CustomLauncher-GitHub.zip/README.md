# Custom Lawnchair – Nova Edition

## GitHub'da derleme
1. Yeni bir repo aç, bu zip'in **içindekileri** (klasörün kendisini değil) repo köküne yükle. `.github/workflows/build.yml` yolu mutlaka olmalı.
2. Repo > **Actions** > **Build APK** (push'ta kendiliğinden başlar, ya da *Run workflow*).
3. Bittiğinde çalışmanın sayfasının altındaki **Artifacts** bölümünden `CustomLauncher-debug-apk` dosyasını indir, içinden `app-debug.apk` çıkar.

Yerelde: `gradle assembleDebug` (Gradle 8.5+, JDK 17).

Lawnchair entegrasyonu için `ENTEGRASYON_REHBERI.md` dosyasına bak.
